package fr.iut.editeur.commande;
public interface Commande {
    void executer();
}
